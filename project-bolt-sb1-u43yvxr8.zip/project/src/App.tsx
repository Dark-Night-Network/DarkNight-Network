import React from 'react';
import AnimatedBackground from './components/AnimatedBackground';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import Community from './components/Community';
import Footer from './components/Footer';

function App() {
  return (
    <div className="relative min-h-screen">
      <AnimatedBackground />
      <Header />
      <main className="relative z-10">
        <Hero />
        <Features />
        <Community />
      </main>
      <Footer />
    </div>
  );
}

export default App;