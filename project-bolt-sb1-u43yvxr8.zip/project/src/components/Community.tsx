import React from 'react';
import { Star, MessageSquare, Calendar, Award } from 'lucide-react';

const Community: React.FC = () => {
  const testimonials = [
    {
      name: "Alex Gaming",
      message: "Best Discord server I've ever joined! The community is amazing and so welcoming.",
      rating: 5
    },
    {
      name: "Sarah Music",
      message: "Found my gaming squad here and made lifelong friends. Highly recommend!",
      rating: 5
    },
    {
      name: "Mike Creative",
      message: "The events and contests are so much fun. There's always something happening!",
      rating: 5
    }
  ];

  return (
    <section id="community" className="py-20 px-6 relative">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Community
            <span className="block bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              Highlights
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            See what our amazing community members have to say about their experience.
          </p>
        </div>

        {/* Community Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 text-center border border-white/10">
            <MessageSquare className="w-8 h-8 text-purple-400 mx-auto mb-3" />
            <div className="text-2xl font-bold text-white mb-1">50K+</div>
            <div className="text-gray-300 text-sm">Messages Daily</div>
          </div>
          
          <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 text-center border border-white/10">
            <Calendar className="w-8 h-8 text-blue-400 mx-auto mb-3" />
            <div className="text-2xl font-bold text-white mb-1">Weekly</div>
            <div className="text-gray-300 text-sm">Events</div>
          </div>
          
          <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 text-center border border-white/10">
            <Award className="w-8 h-8 text-green-400 mx-auto mb-3" />
            <div className="text-2xl font-bold text-white mb-1">100+</div>
            <div className="text-gray-300 text-sm">Prizes Given</div>
          </div>
          
          <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 text-center border border-white/10">
            <Star className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
            <div className="text-2xl font-bold text-white mb-1">4.9/5</div>
            <div className="text-gray-300 text-sm">Rating</div>
          </div>
        </div>

        {/* Testimonials */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10 hover:bg-white/10 transition-all duration-300"
            >
              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>
              
              <p className="text-gray-300 mb-4 italic">"{testimonial.message}"</p>
              
              <div className="text-white font-semibold">- {testimonial.name}</div>
            </div>
          ))}
        </div>

        {/* Final CTA */}
        <div className="text-center">
          <div className="bg-gradient-to-r from-purple-500/20 to-blue-500/20 backdrop-blur-md rounded-3xl p-12 border border-purple-500/30">
            <h3 className="text-3xl md:text-4xl font-bold text-white mb-6">
              Ready to Join the Fun?
            </h3>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Don't miss out on the amazing conversations, events, and friendships waiting for you.
            </p>
            <a 
              href="https://discord.gg/acYWmvet" 
              target="_blank" 
              rel="noopener noreferrer"
              className="group inline-flex items-center space-x-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white px-10 py-5 rounded-2xl font-bold text-xl hover:from-purple-600 hover:to-blue-600 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/25"
            >
              <span>Join Our Discord</span>
              <Star className="w-6 h-6 group-hover:rotate-12 transition-transform" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Community;