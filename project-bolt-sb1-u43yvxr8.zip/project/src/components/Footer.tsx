import React from 'react';
import { Users, Heart, ExternalLink } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="py-12 px-6 border-t border-white/10">
      <div className="container mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-white">ServerHub</span>
          </div>
          
          <p className="text-gray-300 mb-6 max-w-md mx-auto">
            Building connections and creating memories, one conversation at a time.
          </p>
          
          <a 
            href="https://discord.gg/acYWmvet" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center space-x-2 text-purple-400 hover:text-purple-300 transition-colors font-medium"
          >
            <span>Join our Discord Community</span>
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
        
        <div className="border-t border-white/10 pt-8 text-center">
          <p className="text-gray-400 flex items-center justify-center space-x-1">
            <span>Made with</span>
            <Heart className="w-4 h-4 text-red-400 fill-current" />
            <span>for our amazing community</span>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;