import React from 'react';
import { Shield, Gamepad2, Music, Coffee, Trophy, Heart } from 'lucide-react';

const Features: React.FC = () => {
  const features = [
    {
      icon: Shield,
      title: 'Safe Environment',
      description: 'Moderated community with clear rules and active staff to ensure everyone feels welcome.'
    },
    {
      icon: Gamepad2,
      title: 'Gaming Hub',
      description: 'Find teammates, share gameplay moments, and discover new games with fellow gamers.'
    },
    {
      icon: Music,
      title: 'Music & Entertainment',
      description: 'Share your favorite tracks, participate in music nights, and enjoy entertainment together.'
    },
    {
      icon: Coffee,
      title: 'Casual Hangout',
      description: 'Chill conversations, daily topics, and a place to unwind after a long day.'
    },
    {
      icon: Trophy,
      title: 'Events & Contests',
      description: 'Regular community events, giveaways, and contests with amazing prizes.'
    },
    {
      icon: Heart,
      title: 'Supportive Community',
      description: 'A welcoming space where friendships bloom and everyone supports each other.'
    }
  ];

  return (
    <section id="features" className="py-20 px-6 relative">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Why Choose
            <span className="block bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              Our Community?
            </span>
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Discover what makes our Discord server special and why thousands of members call it home.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="group bg-white/5 backdrop-blur-md rounded-2xl p-8 border border-white/10 hover:bg-white/10 hover:border-purple-500/30 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/10"
            >
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <feature.icon className="w-8 h-8 text-white" />
              </div>
              
              <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-purple-300 transition-colors">
                {feature.title}
              </h3>
              
              <p className="text-gray-300 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;